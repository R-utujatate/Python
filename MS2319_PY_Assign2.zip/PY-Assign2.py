import math

# Part 1: Finding all possible pairs of numbers whose product is 1947
product = 1947
pairs = []

# Iterate through all possible divisors
for i in range(1, int(math.sqrt(product)) + 1):
    if product % i == 0:
        pairs.append([i, product // i])

print("Pairs of numbers whose product is 1947:", pairs)

# Part 2: Read two integers M and N from the user
M = int(input("Enter the value for M: "))
N = int(input("Enter the value for N: "))

# Initialize counters
starks_count = 0
lannisters_count = 0
tullies_count = 0

# Run a loop from M to N (inclusive)
for i in range(M, N + 1):
    if (i + 1) % 3 == 0 and (i - 1) % 4 == 0:
        print(f"{i}: Starks")
        starks_count += 1
    elif (i + 1) % 2 == 0 and (i - 1) % 5 == 0:
        print(f"{i}: Lannisters")
        lannisters_count += 1
    else:
        print(f"{i}: Tullies")
        tullies_count += 1

# Print the counts of each category
print(f"\nCount of Starks: {starks_count}")
print(f"Count of Lannisters: {lannisters_count}")
print(f"Count of Tullies: {tullies_count}")
