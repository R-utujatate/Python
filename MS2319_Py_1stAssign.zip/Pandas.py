import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the data into a Pandas DataFrame
df = pd.read_csv("C:\\Users\\Akshay\\Downloads\\olympics.csv")


# 1. How many total countries are listed in the table?
total_countries = df['team'].nunique()
print(f"Total number of countries: {total_countries}")

# 2. How many gold, silver, and bronze medals has India won?
india_medals = df[(df['team'] == 'India') & (df['medal'].notna())]['medal'].value_counts()
print(f"India has won {india_medals.get('Gold', 0)} gold, {india_medals.get('Silver', 0)} silver, and {india_medals.get('Bronze', 0)} bronze medals.")

# 3. Plot a boxplot of ages of all athletes
plt.figure(figsize=(10, 6))
sns.boxplot(data=df, x='age')
plt.title("Boxplot of Ages of All Athletes")
plt.xlabel("Age")
plt.show()

# Plot a boxplot of ages of Indian athletes
plt.figure(figsize=(10, 6))
sns.boxplot(data=df[df['team'] == 'India'], x='age')
plt.title("Boxplot of Ages of Indian Athletes")
plt.xlabel("Age")
plt.show()

# 4. What is the median and mean age of male and female athletes?
age_stats = df.groupby('sex')['age'].agg(['median', 'mean'])
print("Median and Mean Ages of Male and Female Athletes:")
print(age_stats)

# 5. Plot the ratio of male:female athletes for each Olympic.
gender_ratio = df.groupby(['games', 'sex']).size().unstack().fillna(0)
gender_ratio['Ratio'] = gender_ratio['M'] / gender_ratio['F']

plt.figure(figsize=(12, 8))
sns.lineplot(data=gender_ratio['Ratio'])
plt.title("Male:Female Ratio of Athletes for Each Olympic")
plt.ylabel("Male:Female Ratio")
plt.xlabel("Olympic Games")
plt.show()
